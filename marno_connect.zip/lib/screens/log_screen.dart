import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/logger_service.dart';

class LogScreen extends StatelessWidget {
  const LogScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final logger = context.watch<LoggerService>();
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Debug Logs'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () => logger.clear(),
          )
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: logger.logs.length,
        itemBuilder: (context, index) {
          return Text(
            logger.logs[index],
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
          );
        },
      ),
    );
  }
}
