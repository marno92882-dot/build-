import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/config.dart';

class SupportDialog extends StatelessWidget {
  const SupportDialog({Key? key}) : super(key: key);

  Future<void> _launchUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $urlString');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Support Marno Connect"),
      content: const Text(
        "Terima kasih sudah menggunakan Marno Connect. Kamu bisa mendapatkan informasi, update, dan bantuan melalui channel resmi kami.",
      ),
      actions: [
        TextButton(
          onPressed: () {
            _launchUrl(AppConfig.telegramUrl);
            Navigator.pop(context);
          },
          child: const Text("Support Telegram"),
        ),
        TextButton(
          onPressed: () {
            _launchUrl(AppConfig.whatsappUrl);
            Navigator.pop(context);
          },
          child: const Text("Support WhatsApp"),
        ),
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Close", style: TextStyle(color: Colors.grey)),
        ),
      ],
    );
  }
}
