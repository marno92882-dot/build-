import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'logger_service.dart';

class FileManager {
  static Future<File> _getConfigFile() async {
    final directory = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    return File('${directory.path}/localconfig.json');
  }

  static Future<File> _getBackupFile() async {
    final directory = await getExternalStorageDirectory() ?? await getApplicationDocumentsDirectory();
    return File('${directory.path}/localconfig.json.bak');
  }

  static Future<bool> checkConfigExists() async {
    final file = await _getConfigFile();
    return await file.exists();
  }

  static Future<void> createBackupAndWriteNew(LoggerService logger) async {
    final file = await _getConfigFile();
    final backup = await _getBackupFile();

    if (await file.exists()) {
      logger.info("Backing up localconfig.json");
      await file.copy(backup.path);
    }
    
    logger.info("Writing new localconfig.json");
    await file.writeAsString('{"marno_connect": "active"}');
  }

  static Future<void> restoreBackup(LoggerService logger) async {
    final file = await _getConfigFile();
    final backup = await _getBackupFile();

    if (await backup.exists()) {
      logger.info("Restoring backup localconfig.json");
      await backup.copy(file.path);
      await backup.delete();
    } else {
      if (await file.exists()) {
        logger.info("Deleting temporary localconfig.json");
        await file.delete();
      }
    }
  }
}
