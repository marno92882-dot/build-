import 'package:flutter/foundation.dart';

class LoggerService extends ChangeNotifier {
  final List<String> _logs = [];
  List<String> get logs => _logs;

  void info(String message) {
    _logs.add("[INFO] $message");
    notifyListeners();
    debugPrint("[INFO] $message");
  }

  void error(String message) {
    _logs.add("[ERROR] $message");
    notifyListeners();
    debugPrint("[ERROR] $message");
  }

  void clear() {
    _logs.clear();
    notifyListeners();
  }
}
