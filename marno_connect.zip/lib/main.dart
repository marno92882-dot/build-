import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/logger_service.dart';
import 'providers/app_state.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  final logger = LoggerService();
  
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: logger),
        ChangeNotifierProvider(create: (_) => AppState(logger)),
      ],
      child: const MarnoApp(),
    ),
  );
}

class MarnoApp extends StatelessWidget {
  const MarnoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Marno Connect',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121212),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1F1F1F),
          elevation: 0,
        ),
        colorScheme: const ColorScheme.dark(
          primary: Colors.blueAccent,
          secondary: Colors.blueAccent,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
