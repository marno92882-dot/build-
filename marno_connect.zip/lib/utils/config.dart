class AppConfig {
  static const String appName = "Marno Connect";
  static const String telegramUrl = "https://t.me/marnoconnect_support";
  static const String whatsappUrl = "https://wa.me/6280000000000";
  static const int defaultPort = 5030;
  static const int maxPortTries = 100;
  
  // Package names untuk deteksi
  static const String ffPackage = "com.dts.freefireth";
  static const String ffMaxPackage = "com.dts.freefiremax";
}
