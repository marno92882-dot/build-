# Marno Connect

Aplikasi Flutter lengkap untuk Marno Connect.

## Prasyarat
- Flutter SDK (versi terbaru 3.x)
- Android Studio / Android SDK

## Cara Install & Menjalankan
1. Ekstrak file zip ini: `unzip marno_connect.zip`
2. Masuk ke direktori: `cd marno_connect`
3. Download dependency: `flutter pub get`
4. Jalankan aplikasi: `flutter run`
5. Build APK Release: `flutter build apk --release`

## Lokasi APK Hasil Build
Setelah proses build selesai, APK release dapat ditemukan di:
`build/app/outputs/flutter-apk/app-release.apk`

## Konfigurasi
- **Mengganti Logo**: Ganti file `assets/logo.png` dengan logo Anda (pastikan ukurannya sesuai dan nama file tetap `logo.png`).
- **Mengganti Link Telegram/WhatsApp & Port Default**: Buka file `lib/utils/config.dart` dan ubah variabel yang tersedia.

## Penjelasan Permission
Aplikasi ini meminta izin:
- `QUERY_ALL_PACKAGES`: Untuk mendeteksi apakah Free Fire / Free Fire MAX benar-benar terinstall.
- `VpnService` / `FOREGROUND_SERVICE`: Untuk menjalankan service koneksi di background agar tidak mati saat aplikasi ditutup.
- `POST_NOTIFICATIONS`: Untuk menampilkan status koneksi persisten di laci notifikasi.
- `STORAGE`: Untuk mengelola file `localconfig.json` di penyimpanan lokal.
