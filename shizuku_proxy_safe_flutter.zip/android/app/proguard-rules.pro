# Keep Flutter and plugin entry points as required by their runtime.
-keep class io.flutter.** { *; }
-keep class com.example.shizukuproxy.** { *; }
