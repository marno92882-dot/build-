#!/usr/bin/env python3
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5030

class Handler(BaseHTTPRequestHandler):
    def _send(self, code, payload):
        raw = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path == "/Ping":
            self._send(200, {"ok": True, "service": "local", "port": PORT})
        else:
            self._send(404, {"ok": False, "error": "not_found"})

    def do_POST(self):
        if self.path == "/MajorLogin":
            # Deliberately does not decrypt, parse, modify, or collect credentials.
            self._send(501, {
                "ok": False,
                "error": "credential_interception_disabled"
            })
        else:
            self._send(404, {"ok": False, "error": "not_found"})

    def log_message(self, fmt, *args):
        print(fmt % args, flush=True)

HTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
