import 'package:dio/dio.dart';

class VercelService {
  final Dio _dio = Dio();

  Future<void> sendSafeEvent({
    required String endpoint,
    required Map<String, dynamic> event,
  }) async {
    // Sends operational telemetry only. No authentication tokens or login
    // response bodies are accepted by this service.
    await _dio.post(endpoint, data: event);
  }
}
