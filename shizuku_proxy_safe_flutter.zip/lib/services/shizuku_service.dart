import 'dart:async';
import 'package:shizuku_api/shizuku_api.dart';

class ShizukuService {
  Timer? _timer;

  Future<bool> isConnected() async {
    try {
      return await ShizukuApi.isShizukuAvailable();
    } catch (_) {
      return false;
    }
  }

  Future<bool> requestPermission() async {
    try {
      final available = await ShizukuApi.isShizukuAvailable();
      if (!available) return false;
      return await ShizukuApi.requestPermission();
    } catch (_) {
      return false;
    }
  }

  void startPeriodicCheck(Future<void> Function(bool) onChanged) {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) async {
      await onChanged(await isConnected());
    });
  }

  void dispose() => _timer?.cancel();
}
