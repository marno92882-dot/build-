import 'dart:io';
import 'dart:math';

class PortService {
  Future<int?> findAvailable({int preferred = 5030}) async {
    if (await _available(preferred)) return preferred;
    final random = Random();
    for (var i = 0; i < 80; i++) {
      final p = 10000 + random.nextInt(40000);
      if (await _available(p)) return p;
    }
    return null;
  }

  Future<bool> _available(int port) async {
    try {
      final socket = await ServerSocket.bind(InternetAddress.loopbackIPv4, port);
      await socket.close();
      return true;
    } catch (_) {
      return false;
    }
  }
}
