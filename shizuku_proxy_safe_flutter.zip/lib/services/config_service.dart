import 'dart:convert';
import 'package:shizuku_api/shizuku_api.dart';
import '../models/server_config.dart';

class ConfigService {
  Future<void> write(ServerConfig config) async {
    final data = jsonEncode(config.toJson());
    final escaped = data.replaceAll("'", r"'\''");
    final cmd =
        "mkdir -p '${config.configPath.substring(0, config.configPath.lastIndexOf('/'))}' && "
        "printf '%s' '$escaped' > '${config.configPath}'";
    final result = await ShizukuApi.runCommand(cmd);
    if (result.exitCode != 0) {
      throw Exception('Failed to write localconfig.json: ${result.stderr}');
    }
  }

  Future<void> remove(ServerConfig config) async {
    final result = await ShizukuApi.runCommand("rm -f '${config.configPath}'");
    if (result.exitCode != 0) {
      throw Exception('Failed to remove localconfig.json: ${result.stderr}');
    }
  }
}
