import 'dart:async';
import 'package:process_run/process_run.dart';

class PythonService {
  Process? _process;

  Future<void> start(String scriptPath, int port) async {
    await stop();
    _process = await runExecutableArguments(
      'python3',
      [scriptPath, '$port'],
      runInShell: true,
      startProcess: true,
    );
  }

  Future<void> stop() async {
    final p = _process;
    _process = null;
    if (p != null) {
      p.kill();
      await p.exitCode;
    }
  }

  bool get isRunning => _process != null;
}
