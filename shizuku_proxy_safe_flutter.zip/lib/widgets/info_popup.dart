import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../utils/constants.dart';

class InfoPopup extends StatelessWidget {
  const InfoPopup({super.key});

  Future<void> _open(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Shizuku Proxy Manager'),
      content: const Text(
        'Local service manager dengan integrasi Shizuku, pemilihan port, '
        'localconfig.json, lifecycle service, dan log aktivitas.',
      ),
      actions: [
        TextButton(
          onPressed: () => _open(AppConstants.whatsappChannel),
          child: const Text('Support WhatsApp Channel'),
        ),
        TextButton(
          onPressed: () => _open(AppConstants.telegramChannel),
          child: const Text('Support Telegram Channel'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Back / Close'),
        ),
      ],
    );
  }
}
