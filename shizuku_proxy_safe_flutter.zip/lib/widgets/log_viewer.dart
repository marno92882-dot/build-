import 'package:flutter/material.dart';
import '../models/log_entry.dart';

class LogViewer extends StatelessWidget {
  final List<LogEntry> logs;

  const LogViewer({super.key, required this.logs});

  @override
  Widget build(BuildContext context) {
    if (logs.isEmpty) {
      return const Center(child: Text('Belum ada log.'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: logs.length,
      itemBuilder: (_, i) {
        final e = logs[logs.length - 1 - i];
        return ListTile(
          dense: true,
          title: Text(e.message),
          subtitle: Text('${e.time} • ${e.level}'),
        );
      },
    );
  }
}
