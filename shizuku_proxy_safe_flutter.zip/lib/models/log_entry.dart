class LogEntry {
  final DateTime time;
  final String level;
  final String message;

  const LogEntry({
    required this.time,
    required this.level,
    required this.message,
  });
}
