enum GameVariant { normal, max }

class ServerConfig {
  final int port;
  final GameVariant game;

  const ServerConfig({required this.port, required this.game});

  String get configPath => game == GameVariant.normal
      ? '/storage/emulated/0/Android/data/com.dts.freefireth/files/localconfig.json'
      : '/storage/emulated/0/Android/data/com.dts.freefiremax/files/localconfig.json';

  Map<String, dynamic> toJson() => {
        'serverUrl': 'http://0.0.0.0:$port/',
      };
}
