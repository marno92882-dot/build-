class AppConstants {
  static const appName = 'Shizuku Proxy Manager';
  static const packageNormal = 'com.dts.freefireth';
  static const packageMax = 'com.dts.freefiremax';
  static const normalConfig =
      '/storage/emulated/0/Android/data/com.dts.freefireth/files/localconfig.json';
  static const maxConfig =
      '/storage/emulated/0/Android/data/com.dts.freefiremax/files/localconfig.json';

  // Replace these with your own public support channels.
  static const whatsappChannel = 'https://whatsapp.com/channel/REPLACE_ME';
  static const telegramChannel = 'https://t.me/REPLACE_ME';
}
