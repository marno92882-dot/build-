import 'package:flutter/services.dart';

Future<void> closeApp() async {
  await SystemNavigator.pop();
}
