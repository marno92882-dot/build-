import 'package:flutter/material.dart';
import '../models/server_config.dart';

class SettingsScreen extends StatelessWidget {
  final GameVariant selected;
  final ValueChanged<GameVariant> onChanged;

  const SettingsScreen({
    super.key,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          RadioListTile(
            title: const Text('Free Fire Normal'),
            value: GameVariant.normal,
            groupValue: selected,
            onChanged: (v) => onChanged(v!),
          ),
          RadioListTile(
            title: const Text('Free Fire MAX'),
            value: GameVariant.max,
            groupValue: selected,
            onChanged: (v) => onChanged(v!),
          ),
        ],
      ),
    );
  }
}
