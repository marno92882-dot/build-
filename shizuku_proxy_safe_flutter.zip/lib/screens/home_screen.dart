import 'dart:async';
import 'package:flutter/material.dart';
import '../models/log_entry.dart';
import '../models/server_config.dart';
import '../services/shizuku_service.dart';
import '../services/port_service.dart';
import '../services/config_service.dart';
import '../services/python_service.dart';
import '../utils/helpers.dart';
import '../widgets/animated_button.dart';
import 'log_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final shizuku = ShizukuService();
  final ports = PortService();
  final config = ConfigService();
  final python = PythonService();

  final List<LogEntry> logs = [];
  bool shizukuConnected = false;
  bool running = false;
  bool busy = false;
  GameVariant game = GameVariant.normal;
  int? port;

  void log(String level, String message) {
    if (!mounted) return;
    setState(() {
      logs.add(LogEntry(time: DateTime.now(), level: level, message: message));
    });
  }

  @override
  void initState() {
    super.initState();
    _checkShizuku();
    shizuku.startPeriodicCheck((ok) async {
      if (!ok && running) {
        log('ERROR', 'Shizuku disconnected; stopping service.');
        await _stop();
      }
      if (mounted) setState(() => shizukuConnected = ok);
    });
  }

  Future<void> _checkShizuku() async {
    final ok = await shizuku.isConnected();
    if (!mounted) return;
    setState(() => shizukuConnected = ok);
    if (!ok) {
      final connect = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: const Text('Shizuku diperlukan'),
          content: const Text(
            'Sambungkan Shizuku lalu tekan Coba Lagi. '
            'Tanpa Shizuku aplikasi akan ditutup.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Keluar'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Coba Lagi'),
            ),
          ],
        ),
      );
      if (connect == true) {
        await shizuku.requestPermission();
        await _checkShizuku();
      } else {
        await closeApp();
      }
    }
  }

  Future<void> _start() async {
    if (!shizukuConnected || busy) return;
    setState(() => busy = true);
    try {
      final p = await ports.findAvailable();
      if (p == null) throw Exception('Tidak ada port tersedia.');
      final cfg = ServerConfig(port: p, game: game);
      await config.write(cfg);
      port = p;
      // The actual Python interpreter must exist on the device.
      // This manager deliberately does not inject authentication interception.
      try {
        await python.start('assets/local_server.py', p);
      } catch (e) {
        await config.remove(cfg);
        throw Exception('Python runtime tidak tersedia: $e');
      }
      running = true;
      log('INFO', 'Service started on port $p');
    } catch (e) {
      log('ERROR', '$e');
      running = false;
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _stop() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      await python.stop();
      if (port != null) {
        await config.remove(ServerConfig(port: port!, game: game));
      }
      log('INFO', 'Service stopped and config removed.');
      port = null;
      running = false;
    } catch (e) {
      log('ERROR', '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    shizuku.dispose();
    python.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shizuku Proxy Manager'),
        actions: [
          IconButton(
            icon: const Icon(Icons.article_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => LogScreen(logs: logs)),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () async {
              final result = await Navigator.push<GameVariant>(
                context,
                MaterialPageRoute(
                  builder: (_) => SettingsScreen(
                    selected: game,
                    onChanged: (v) => Navigator.pop(context, v),
                  ),
                ),
              );
              if (result != null && !running) setState(() => game = result);
            },
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                shizukuConnected ? Icons.link : Icons.link_off,
                size: 72,
              ),
              const SizedBox(height: 16),
              Text(
                shizukuConnected ? 'Shizuku Connected' : 'Shizuku Disconnected',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                running
                    ? 'Running • port ${port ?? '-'}'
                    : 'Service stopped',
              ),
              const SizedBox(height: 28),
              AnimatedButton(
                label: busy
                    ? 'Processing...'
                    : running
                        ? 'Stop'
                        : 'Start',
                icon: running ? Icons.stop : Icons.play_arrow,
                onPressed: busy
                    ? null
                    : () => running ? _stop() : _start(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
