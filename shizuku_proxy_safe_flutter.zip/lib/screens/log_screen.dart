import 'package:flutter/material.dart';
import '../models/log_entry.dart';
import '../widgets/log_viewer.dart';

class LogScreen extends StatelessWidget {
  final List<LogEntry> logs;
  const LogScreen({super.key, required this.logs});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activity Log')),
      body: LogViewer(logs: logs),
    );
  }
}
