# Shizuku Proxy Safe Manager

This project implements the Flutter UI, Shizuku state checks, port selection,
localconfig.json management, logging, lifecycle handling, and a local HTTP
service manager.

## Important security boundary

The requested `MajorLogin` AES decryption, protobuf decoding/modification,
credential/token extraction, and forwarding of authentication responses to a
remote collector are intentionally NOT implemented. That combination can
intercept and exfiltrate authentication material. The project therefore keeps
the local service generic and does not collect `access_token`, `open_id`, or
login response credentials.

## Setup

1. Install Flutter and Android SDK.
2. Run `flutter pub get`.
3. Open the project in Android Studio.
4. Build with:
   `flutter build apk --release --obfuscate --split-debug-info=build/symbols`
5. Install Shizuku and grant the application Shizuku permission.
6. Select Free Fire Normal or MAX in Settings.
7. Start the local service.

## Android

The included Android configuration targets SDK 34 and min SDK 21. Android
scoped-storage restrictions mean that direct writes to
`/storage/emulated/0/Android/data/...` can depend on OS/device behavior.
The service uses Shizuku shell commands for the config file operation.

## Python

A generic local HTTP server reference is included in `assets/local_server.py`.
On Android, `process_run` does not itself install a Python interpreter.
A real Python runtime must therefore be supplied by the deployment environment
before executing that script. The Flutter application does not silently assume
Python exists.

## Endpoints

The safe local server exposes `/Ping` and a generic `/MajorLogin` response.
It does not decrypt, alter, or collect authentication credentials.

## Support links

Replace the placeholders in `lib/utils/constants.dart`.
